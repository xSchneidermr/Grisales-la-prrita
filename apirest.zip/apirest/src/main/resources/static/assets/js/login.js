
$(document).ready(function () {
});
async function iniciarSesion() {
    const email = document.getElementById("txtEmailIniciar").value;
    const password = document.getElementById("txtPasswordIniciar").value;

    const loginData = {
        email: email,
        password: password
    };

    fetch("/api/usuarios/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(loginData)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error("Credenciales inválidas");
            }
            return response.text();
        })
        .then(data => {
            document.location.href = "index.html";
        })
        .catch(error => {
            alert(error.message);
        });
}